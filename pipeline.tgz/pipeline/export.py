import os as _os
_D1 = chr(47)+'tmp'+chr(47)+'li'
_D2 = chr(47)+'tmp'+chr(47)+'work'
SRC  = _os.environ.get('ND_SRC',  _D1)
WORK = _os.environ.get('ND_WORK', _D2)

import pandas as pd, numpy as np, json, re
def norm_co(x):
    x=str(x).lower().strip()
    x=re.sub(r'\s*[·|].*$','',x)
    x=re.sub(r'\b(a/s|aps|group|gruppen|as|ab|inc|ltd|plc|denmark|danmark|nordics?)\b','',x)
    return re.sub(r'[^a-z0-9æøå]+','',x)
mg=pd.read_pickle(_os.path.join(WORK, 'final2.pkl'))
inv=pd.read_csv(_os.path.join(SRC, 'Invitations.csv')).fillna('')
def nu(u):
    u=str(u).strip().lower().rstrip('/')
    return re.sub(r'^https?://(www\.)?linkedin\.com/in/','',u).split('?')[0]
out=inv[inv.Direction=='OUTGOING'].copy(); out['k']=out['inviteeProfileUrl'].apply(nu)
pending=out[~out['k'].isin(set(mg['key']))]
# Everyone, not just the Denmark-scored. Cutting 1,233 people out of the file meant
# search could not find a former colleague or a London recruiter - they were never in
# the page to be found. The Denmark tier is a FILTER on the queue, not a gate on the data.
d=mg.copy()
d=d.sort_values('prio',ascending=False).rename(columns={'Connected On':'ConnectedOn'})
def clean(t):
    t=re.sub(r'\s+',' ',str(t)).strip()
    return t[:340]
recs=[]
for r in d.itertuples():
    recs.append(dict(
        n=r.name, u=r.URL, co=str(r.Company), ck=norm_co(r.Company), p=str(r.Position),
        con=(r.ConnectedOn.strftime('%Y-%m-%d') if pd.notna(r.ConnectedOn) else ''),
        t=r.dk_tier, w=r.dk_why, rt=r.role_tags, rs=int(r.role_score),
        a=r.action, pr=round(float(r.prio),1), st=r.status,
        m=int(r.msgs), s=int(r.sent), rc=int(r.recv),
        ld=(r.last_date.strftime('%Y-%m-%d') if pd.notna(r.last_date) else ''),
        ds=(int(r.days_since) if pd.notna(r.days_since) else None),
        lt=clean(r.last_text) if r.msgs else '',
        lm=('me' if r.last_from_me is True else ('them' if r.last_from_me is False else '')),
        dd=r.due_date, dl=r.due_label, ws=r.who_started if r.msgs else '',
        lv=bool(getattr(r,'live_new',False))))
# company rollup (DK high only)
h=mg[mg.dk_tier=='high']
h=h.copy(); h['ck']=h['Company'].apply(norm_co)
h['disp']=h['Company']
cg=h[h.ck!=''].groupby('ck').agg(
    Company=('disp',lambda s:s.value_counts().index[0]),
    n=('name','size'), replied=('recv',lambda s:(s>0).sum()),
    poteam=('role_score',lambda s:(s>=30).sum()), never=('msgs',lambda s:(s==0).sum()),
    hot=('prio',lambda s:(s>=95).sum())).reset_index()
cg=cg[cg.n>=2].sort_values(['n'],ascending=False)
comps=[dict(c=r.Company,ck=r.ck,n=int(r.n),r=int(r.replied),k=int(r.poteam),nv=int(r.never),h=int(r.hot)) for r in cg.itertuples()]

msgs=pd.read_csv(_os.path.join(SRC, 'messages.csv'))
_md=pd.to_datetime(msgs['DATE'].astype(str).str.replace(' UTC',''),errors='coerce')
_newest_msg = _md.max()
_conn_dates = pd.to_datetime(mg['ConnectedOn'],errors='coerce') if 'ConnectedOn' in mg else None
stats=dict(
 total_conn=int(len(mg)), dk_high=int((mg.dk_tier=='high').sum()), dk_med=int((mg.dk_tier=='medium').sum()),
 threads=int((mg.msgs>0).sum()), total_msgs=int(len(msgs)),
 sent_total=int(mg['sent'].sum()), recv_total=int(mg['recv'].sum()),
 pending_inv=int(len(pending)), inv_sent=int(len(out)),
 dk_replied=int(((mg.dk_tier=='high')&(mg.recv>0)).sum()),
 dk_contacted=int(((mg.dk_tier=='high')&(mg.msgs>0)).sum()),
 dk_never=int(((mg.dk_tier=='high')&(mg.msgs==0)).sum()),
 # LinkedIn assembles the snapshot offline, so the newest message it serves can be
 # many hours behind reality. Show that watermark rather than implying live data.
 newest_msg=(_newest_msg.strftime('%Y-%m-%d %H:%M') if pd.notna(_newest_msg) else ''),
 built_at=pd.Timestamp.now().strftime('%Y-%m-%d %H:%M'))
# --- this week, so the page can show whether the week held outreach or only tooling ---
_wk=pd.Timestamp.now().normalize()-pd.Timedelta(days=7)
def _nu2(u):
    from urllib.parse import unquote
    return re.sub(r'^https?://(www\.)?linkedin\.com/in/','',unquote(str(u)).strip().lower().rstrip('/')).split('?')[0]
# msg.py wrote down whose export this is; reuse it rather than guessing again.
try:
    _mine=open(_os.path.join(WORK,'_me.txt'),encoding='utf-8').read().strip()
except Exception:
    _mine=''
_recent=msgs[_md>=_wk]
_sent7=int((_recent['SENDER PROFILE URL'].apply(_nu2)==_mine).sum())
_recv7=int(len(_recent)-_sent7)
# Connection requests: sent, accepted, still waiting. "Accepted" is not a column
# LinkedIn gives you -- an invitation that worked simply becomes a connection, so
# it is the outgoing invites whose person now appears in Connections.
_inv7=_acc7=_wait=0
try:
    _iv=pd.to_datetime(inv['Sent At'],format='%m/%d/%y, %I:%M %p',errors='coerce')
    if _iv.isna().all():
        _iv=pd.to_datetime(inv['Sent At'],errors='coerce')
    _o=inv['Direction']=='OUTGOING'
    _inv7=int((_o&(_iv>=_wk)).sum())
    _conn=set(mg['key'])
    _k=inv['inviteeProfileUrl'].apply(nu)
    _isconn=_k.isin(_conn)
    _acc7=int((_o&_isconn&(_iv>=_wk)).sum())
    _wait=int((_o&~_isconn).sum())
except Exception as _e:
    print('invite stats skipped:',type(_e).__name__,_e)
stats['week']=dict(sent=_sent7,recv=_recv7,invites=_inv7,accepted=_acc7,waiting=_wait)
# The live changelog knows about activity the batch snapshot has not caught up with.
# It cannot say WHO a sent message went to -- LinkedIn omits the recipient -- so it is
# reported as a gap rather than folded into the contacts.
_cl_path=_os.path.join(WORK,'_changelog.json')
if _os.path.exists(_cl_path):
    try:
        _cl=json.load(open(_cl_path,encoding='utf-8'))
        _cut=_newest_msg
        _newer=0
        # threads the live feed knows about that the snapshot has never seen: these are
        # conversations started since the last rebuild, and LinkedIn does not say with
        # whom, so they cannot be placed on anyone's card. Report the count honestly.
        _known_cids=set(msgs['CONVERSATION ID'].dropna().astype(str))
        _pending=sum(1 for _t in _cl.get('threads',{}) if _t not in _known_cids)
        for _t in _cl.get('threads',{}).values():
            if _t.get('last') and pd.notna(_cut) and pd.Timestamp(_t['last'],unit='ms')>_cut: _newer+=1
        stats['live']=dict(sent=_cl.get('messages_sent',0), recv=_cl.get('messages_received',0),
                           invites=_cl.get('invitations',0), threads_newer=_newer,
                           joined=int(d['live_new'].astype(bool).sum()) if 'live_new' in d else 0,
                           pending=_pending,
                           newest=(pd.Timestamp(_cl['newest'],unit='ms').strftime('%Y-%m-%d %H:%M')
                                   if _cl.get('newest') else ''))
    except Exception as _e:
        # silence here once hid a broken live block for a whole build; say it out loud
        print('live stats skipped:', type(_e).__name__, _e)
# monthly outreach volume from messages sent by me
mm=mg[mg.msgs>0]
_seed={}
_sp=_os.path.join(WORK,'desk-state.json')
if _os.path.exists(_sp):
    try:
        _seed=json.load(open(_sp,encoding='utf-8'))
        print('seeded',len(_seed),'saved marks from desk-state.json')
    except Exception as _e:
        print('desk-state.json unreadable:',_e)
json.dump(dict(rows=recs,comps=comps,stats=stats,seed=_seed),open(_os.path.join(WORK, 'data.json'),'w',encoding='utf-8'),ensure_ascii=False)
print(stats); print('rows',len(recs),'comps',len(comps))
import os; print('size KB', os.path.getsize(_os.path.join(WORK, 'data.json'))//1024)
print(d['action'].value_counts())
