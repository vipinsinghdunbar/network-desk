# -*- coding: utf-8 -*-
"""
outcomes.py - does the ranking actually predict what happens?

The desk has always told you who to write to. It has never been able to tell you
whether writing to them worked, because the one thing LinkedIn does not know is
recorded here by hand, in the page, and then never read by anything. The six
outcomes in desk-state.json go in and this is where they come out.

What this measures
------------------
1. Resolution rate. How many cards have an outcome at all. Until that number is
   high, nothing below it means much.
2. Per action category: how many were resolved, and how many turned into a real
   outcome (meeting / referral / applied) rather than silence. The ranking in
   refine.py PRIO says "Reply now - they asked to meet" is worth 100 and
   "Reply - unanswered message" is worth 70. This is the test of whether that
   is true.
3. Whether priority predicts outcome at all, as a rank correlation. If the
   ranking is sound this should be clearly positive. If it is near zero, the
   ordering is decoration and should be rebuilt from the evidence.
4. The same split by Denmark tier, because the tier filter is what you actually
   look at.

What it deliberately does not do
-------------------------------
It does not claim causation, and it will say so in its own output. You record an
outcome for people you decided to write to, and the high-priority cards are the
ones on screen in front of you. So the sample is selected twice over: first by
your judgement, then by the ranking itself. That is a limit of the data as it
exists, not something this script can repair.

It also refuses to draw a conclusion from too few rows. Every table carries the
count, and anything under MIN_N is marked too thin to read. A win rate of 100%
off three outcomes is not a finding, and saying so is most of the value here.

No new dependencies: numpy and pandas only, no scipy. The two statistics used
are a rank correlation and an interval on a proportion, both computed by hand.
"""

import json as _json
import os as _os

WORK = _os.environ.get('ND_WORK', '/tmp/work')

import pandas as pd
import numpy as np

MIN_N = 8          # below this a rate is noise, and is labelled as such

# What the recorded outcome actually means. "replied" is real but it is the
# floor, not the goal - someone answering you is not the same as a meeting, and
# a ranking that cannot tell those apart is not doing its job.
STRONG = ('meeting', 'referral', 'applied')
SOFT = ('replied',)
LOSS = ('dead',)


def wilson(k, n, z=1.96):
    """95% interval on a proportion. A bare percentage with no interval is
    how a 3-out-of-3 gets mistaken for a finding."""
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    d = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / d
    half = z * ((p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5) / d
    return (max(0.0, centre - half), min(1.0, centre + half))


def spearman(x, y):
    """Rank correlation by hand, so this does not need scipy. Returns None when
    either side is constant - a correlation against a flat series is undefined
    and printing 0.00 would read as 'no relationship' when the truth is
    'nothing to compare'."""
    x = pd.Series(x).astype(float)
    y = pd.Series(y).astype(float)
    if len(x) < 3:
        return None
    rx, ry = x.rank(), y.rank()
    if rx.nunique() < 2 or ry.nunique() < 2:
        return None
    return float(rx.corr(ry))


def load_state():
    p = _os.path.join(WORK, 'desk-state.json')
    if not _os.path.exists(p):
        return {}
    try:
        d = _json.load(open(p, encoding='utf-8'))
        return d if isinstance(d, dict) else {}
    except Exception as e:
        print('desk-state.json unreadable:', e)
        return {}


def pct(x):
    return f"{100 * x:.0f}%"


def rate_row(label, sub, outcol):
    """Strong-outcome rate over EVERY resolved row, with an interval.

    The denominator is every outcome recorded, not just the decided-looking ones.
    An earlier version divided by strong+dead only, so a category holding 3
    meetings, 23 replies and 0 deads printed "100% strong" - technically true and
    actively misleading, because 23 people had engaged and it read as a clean
    sweep. A reply is a partial result, and partial results belong in the
    denominator so the categories stay comparable.
    """
    n = len(sub)
    if n == 0:
        return dict(label=label, n=0, strong=0, soft=0, loss=0, strong_pct=None,
                    lo=None, hi=None, thin=True)
    k = int((sub[outcol].isin(STRONG)).sum())
    lo, hi = wilson(k, n)
    return dict(label=label, n=n, strong=k,
                soft=int((sub[outcol].isin(SOFT)).sum()),
                loss=int((sub[outcol].isin(LOSS)).sum()),
                strong_pct=k / n, lo=lo, hi=hi, thin=n < MIN_N)


def main():
    mg = pd.read_pickle(_os.path.join(WORK, 'final2.pkl')).fillna('')
    state = load_state()

    # The page keys its marks by profile slug; msg.py normalised those to 'key'.
    def get_state(u, field):
        v = state.get(u)
        if isinstance(v, dict):
            return (v.get(field) or '')
        return ''

    mg['outcome'] = mg['key'].map(lambda k: str(get_state(k, 'out') or ''))
    mg['done_mark'] = mg['key'].map(lambda k: str(get_state(k, 'done') or ''))
    mg['met_mark'] = mg['key'].map(lambda k: str(get_state(k, 'met') or ''))

    total = len(mg)
    resolved = mg[mg['outcome'] != '']
    high = mg[mg['dk_tier'] == 'high']

    out = dict(total=total, high=len(high), resolved=len(resolved),
               min_n=MIN_N, by_action=[], by_tier=[], overall={}, warns=[])

    print()
    print('=' * 74)
    print('  DOES THE RANKING PREDICT THE OUTCOME?')
    print('=' * 74)
    print()
    print(f"  {total} people on the desk, {len(high)} in the Denmark 'high' tier "
          f"you actually look at.")
    print(f"  {len(resolved)} have an outcome recorded. That is {100*len(resolved)/max(1,total):.1f}% "
          f"of the desk.")

    if len(resolved) == 0:
        print()
        print('  Nothing recorded yet, so there is nothing to learn from yet.')
        print()
        print('  An outcome is set from the select on any card: they replied, a meeting')
        print('  was booked, a referral, you applied there, or it went nowhere.')
        print('  "Went nowhere" counts. It is the only way the desk learns what does')
        print('  not work, and it is the answer nobody can supply from LinkedIn.')
        print()
        _json.dump(out, open(_os.path.join(WORK, 'outcomes.json'), 'w'), ensure_ascii=False)
        return

    # --- per action category, on the tier the queue is drawn from -------------
    print()
    print('-' * 74)
    print('  BY ACTION CATEGORY  (high tier, i.e. the queue you work through)')
    print('-' * 74)
    print()
    print(f"  {'action':<38} {'res':>4} {'meet+':>6} {'reply':>6} {'dead':>5} {'meet+/n':>8}  95%")
    hi_res = resolved[resolved['dk_tier'] == 'high']
    for act, sub in hi_res.groupby('action'):
        r = rate_row(act, sub, 'outcome')
        out['by_action'].append(r)
        if r['n'] == 0:
            continue
        band = f"{pct(r['lo'])}-{pct(r['hi'])}" if r['strong_pct'] is not None else '-'
        flag = '  *thin' if r['thin'] else ''
        sp = pct(r['strong_pct']) if r['strong_pct'] is not None else '-'
        print(f"  {r['label'][:38]:<38} {r['n']:>4} {r['strong']:>6} {r['soft']:>6} "
              f"{r['loss']:>5} {sp:>8}  {band}{flag}")

    # --- does priority rank outcome? -----------------------------------------
    print()
    print('-' * 74)
    print('  DOES PRIORITY PREDICT OUTCOME?')
    print('-' * 74)
    print()
    # score 2 = a meeting, 1 = a reply, 0 = nothing, -1 = dead. Spearman against
    # prio asks one question: do the cards the desk puts at the top do better?
    strength = {'meeting': 3, 'referral': 3, 'applied': 3, 'replied': 1, 'dead': -1}
    for scope, frame in (('high tier', hi_res), ('whole desk', resolved)):
        sc = frame['outcome'].map(strength)
        use = frame[sc.notna()]
        rho = spearman(use['prio'], sc[sc.notna()]) if len(use) >= 3 else None
        if rho is None:
            print(f"  {scope:<10} not enough resolved outcomes to correlate.")
        else:
            print(f"  {scope:<10} rank correlation {rho:+.2f}  (n={len(use)})")
            out['overall'].setdefault(scope, {})['rho'] = rho
            out['overall'][scope]['n'] = len(use)
            # A NEGATIVE correlation is the finding that matters most and the one
            # a two-sided test like `rho > 0.5` throws away. It means the cards
            # the desk puts at the top are the ones that do worst, so the queue is
            # not merely uninformative, it is pointing the wrong way.
            if rho <= -0.30:
                print(f"             {'':14}NEGATIVE. The cards at the top of the queue are the")
                print(f"             {'':14}ones that did worst. The ordering is not just")
                print(f"             {'':14}uninformative, it is inverted - trust it last.")
                out['warns'].append('inverted:' + scope)
            elif rho < -0.15:
                print(f"             {'':14}negative, though weakly. The top of the queue is")
                print(f"             {'':14}not beating the bottom.")
                out['warns'].append('weakly-negative:' + scope)
            elif rho <= 0.15:
                print(f"             {'':14}close to zero. The ordering is not carrying information.")
            elif rho <= 0.50:
                print(f"             {'':14}positive but modest. The top of the queue is only")
                print(f"             {'':14}somewhat better than the rest.")
            else:
                print(f"             {'':14}strong. The queue is pointing at the right people.")
    print()
    print('  Read this with its limit in mind: you record outcomes for people you')
    print('  chose to write to, and the top cards are the ones in front of you. The')
    print('  sample is selected twice. It can show the ranking is not working. It')
    print('  cannot prove the ranking is the cause of anything working.')

    # --- by tier --------------------------------------------------------------
    print()
    print('-' * 74)
    print('  BY DENMARK TIER')
    print('-' * 74)
    print()
    for tier in ('high', 'medium', 'low'):
        sub = resolved[resolved['dk_tier'] == tier]
        if len(sub) == 0:
            continue
        r = rate_row(tier, sub, 'outcome')
        out['by_tier'].append(r)
        sp = pct(r['strong_pct']) if r['strong_pct'] is not None else '-'
        flag = '  *thin' if r['thin'] else ''
        print(f"  {tier:<38} {r['n']:>4} {sp:>8}{flag}")

    # --- what is actually holding the record back ---------------------------
    acted = mg[(mg['outcome'] != '') | (mg['done_mark'] != '') | (mg['met_mark'] != '')]
    if len(resolved) < MIN_N * 2:
        print()
        print('  *thin means fewer than ' + str(MIN_N) + ' decided outcomes behind the number.')
        print('  Those rows are shown so you can see the size of the sample, not because')
        print('  the percentage means anything yet.')
    if len(resolved) < len(high) * 0.10:
        out['warns'].append('thin')
        print()
        print('  Most of the desk has never been resolved, so any ranking fitted to this')
        print(f"  would be fitted to {len(resolved)} rows. The number to raise first is the")
        print('  number of recorded outcomes, not the ranking.')

    _json.dump(out, open(_os.path.join(WORK, 'outcomes.json'), 'w'), ensure_ascii=False)
    print()
    print('=' * 74)
    print()


if __name__ == '__main__':
    main()
