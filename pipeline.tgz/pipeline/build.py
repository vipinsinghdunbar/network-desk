# -*- coding: utf-8 -*-
import os as _os
_D1 = chr(47)+'tmp'+chr(47)+'li'
_D2 = chr(47)+'tmp'+chr(47)+'work'
SRC  = _os.environ.get('ND_SRC',  _D1)
WORK = _os.environ.get('ND_WORK', _D2)

import json,re,os
def esc_html(s): return ''.join(c if ord(c)<128 else '&#%d;'%ord(c) for c in s)
def esc_js(s):
    out=[]
    for c in s:
        o=ord(c)
        if o<128: out.append(c)
        elif o>0xFFFF:
            o-=0x10000
            out.append('\\u%04x\\u%04x'%(0xD800+(o>>10),0xDC00+(o&0x3FF)))
        else: out.append('\\u%04x'%o)
    return ''.join(out)
def to_ascii(t):
    parts=re.split(r'(<script\b[^>]*>|</script>)',t)
    out=[];inscript=False
    for p in parts:
        if p.startswith('<script'): inscript=True; out.append(p); continue
        if p=='</script>': inscript=False; out.append(p); continue
        out.append(esc_js(p) if inscript else esc_html(p))
    return ''.join(out)
def build(tpl,data,expand,out):
    t=open(tpl,encoding='utf-8').read()
    d=json.dumps(json.load(open(data,encoding='utf-8')),ensure_ascii=True)
    x=json.dumps(json.load(open(expand,encoding='utf-8')),ensure_ascii=True)
    assert '</script>' not in d and '</script>' not in x
    html=to_ascii(t).replace('__DATA__',d).replace('__EXPAND__',x)
    html.encode('ascii')
    open(out,'w',encoding='ascii').write(html)
    print(out,'KB',os.path.getsize(out)//1024,'pure-ascii OK')
build('tpl.html','data.json','expand.json','desk.html')
# The demo is only built where its template exists (the cloud workspace).
# A local rebuild on the user's PC has no demo template and does not need one.
if _os.path.exists(_os.path.join(WORK, 'tpl_demo.html')):
    build('tpl_demo.html','data_demo.json','expand_demo.json','demo.html')
