import os as _os
_D1 = chr(47)+'tmp'+chr(47)+'li'
_D2 = chr(47)+'tmp'+chr(47)+'work'
SRC  = _os.environ.get('ND_SRC',  _D1)
WORK = _os.environ.get('ND_WORK', _D2)

import pandas as pd, re, numpy as np
mg=pd.read_pickle(_os.path.join(WORK, 'final.pkl'))
NOW=pd.Timestamp('2026-09-25')

DECLINE=r"(must decline|i'?ll pass|no thanks?|not interested|don'?t have (the )?time|unfortunately i|sorry.{0,30}(can'?t|not able|no time)|not the right time|no vacan)"
def last_inbound(alltext):
    parts=[p for p in str(alltext).split(' || ') if ' THEM] ' in p]
    return parts[-1] if parts else ''
mg['last_in']=mg['all_text'].apply(last_inbound)
mg['declined']=mg['last_in'].str.lower().str.contains(DECLINE,regex=True,na=False)

# --- detect a promised future follow-up moment and whether it's now due ---
MONTHS={'january':1,'february':2,'march':3,'april':4,'may':5,'june':6,'july':7,'august':8,
        'september':9,'october':10,'november':11,'december':12,'august.':8}
def commitment(alltext):
    t=str(alltext); tl=t.lower()
    cues=[]
    for mname,mnum in MONTHS.items():
        if re.search(r'\b(in|after|early|late|beginning of|start of|reconnect in|until|till|back in|talk to you in)\s+'+mname+r'\b',tl):
            cues.append(('month',mnum,mname))
    wk=re.search(r'week\s*(\d{1,2})',tl)
    if wk: cues.append(('week',int(wk.group(1)),'week '+wk.group(1)))
    if re.search(r'(after (the )?(summer|holidays?|vacation|sommerferie)|efter ferien|when i(\'m| am) back|once i(\'m| am) back|after my leave)',tl):
        cues.append(('summer',8,'after the summer/holidays'))
    if re.search(r'(check in (in )?10-15 days|in a couple of weeks|in (a )?few weeks|later this month|next month)',tl):
        cues.append(('soon',0,'a few weeks later'))
    return cues
def due(row):
    cues=commitment(row['all_text'])
    if not cues: return '', ''
    last=row['last_date']
    if pd.isna(last): return '',''
    best=None
    for kind,val,label in cues:
        if kind=='month':
            y=last.year if val>=last.month else last.year+1
            d=pd.Timestamp(year=y,month=val,day=1)
        elif kind=='week':
            if not (1<=val<=53): continue
            d=pd.Timestamp.fromisocalendar(last.year if val>=last.isocalendar().week else last.year+1, val, 1)
        elif kind=='summer':
            d=pd.Timestamp(year=last.year,month=8,day=1)
            if d<last: d=pd.Timestamp(year=last.year+1,month=8,day=1)
        else:
            d=last+pd.Timedelta(days=18)
        if d<last: continue
        if best is None or d<best[0]: best=(d,label)
    if best is None: return '',''
    return (best[0].strftime('%Y-%m-%d') if best[0]<=NOW+pd.Timedelta(days=45) else ''), best[1]
mg[['due_date','due_label']]=mg.apply(lambda r: pd.Series(due(r)),axis=1)
mg['due_now']=(mg['due_date']!='') & (pd.to_datetime(mg['due_date'],errors='coerce')<=NOW) & (mg['msgs']>0)

def action2(r):
    if r['msgs']==0: return 'Never contacted — open door'
    if r['status']=='Waiting on you' and r['declined']: return 'Closed — they declined'
    if r['status']=='Waiting on you' and r['reply_type']=='Warm — wants to talk': return 'Reply now — they asked to meet'
    if r['due_now'] and not r['declined']: return 'Promised follow-up — now due'
    if r['due_now'] and r['declined']: return 'They said "later" — window open'
    if r['status']=='Waiting on you' and r['reply_type'] in ('Substantive reply','Neutral'): return 'Reply — unanswered message'
    if r['status']=='Waiting on you' and r['reply_type']=='Polite close': return 'Optional — thread closed politely'
    if r['declined'] and r['recv']>0: return 'Closed — they declined'
    if r['status']=='Two-way conversation' and r['ever_warm'] and r['days_since']>=30: return 'Warm lead gone quiet — revive'
    if r['status']=='Two-way conversation' and r['days_since']>=30: return 'Replied once, then quiet'
    if r['status']=='Two-way conversation': return 'Live conversation'
    if r['status']=='No reply yet': return 'Recently sent — wait'
    # "Chase again" used to swallow 59% of the desk in one undifferentiated pile.
    # Silence is not one state: someone who answered you once and went quiet is a
    # different prospect from someone who has ignored two messages.
    if r['status']=='Never replied' and r['days_since']>=21:
        if r['sent']>=2:                  return 'Ignored twice — let it go'
        if r['days_since']>=365:          return 'Cold — one message, long ago'
        return 'Chase again — no reply in 3 weeks'
    if r['status']=='Never replied': return 'Recently sent — wait'
    return 'Closed — they declined' if r['declined'] else 'Optional — thread closed politely'
mg['action']=mg.apply(action2,axis=1)
PRIO={'Reply now — they asked to meet':100,'Promised follow-up — now due':95,'Warm lead gone quiet — revive':82,
 'Reply — unanswered message':70,'They said "later" — window open':66,'Live conversation':60,
 'Chase again — no reply in 3 weeks':55,'Replied once, then quiet':50,'Never contacted — open door':45,
 'Recently sent — wait':30,'Cold — one message, long ago':22,
 'Optional — thread closed politely':18,'Ignored twice — let it go':8,'Closed — they declined':5}
mg['prio']=mg['action'].map(PRIO).fillna(0)+mg['role_score']*0.6
# Within the chase list, a message sent two months ago is far more likely to land than
# one from two years ago. Age it down so the freshest silences surface first.
chase = mg['action']=='Chase again — no reply in 3 weeks'
mg.loc[chase,'prio'] -= (mg.loc[chase,'days_since']/30).clip(upper=26)
mg.loc[mg.dk_tier!='high','prio']*=0.55
mg.to_pickle(_os.path.join(WORK, 'final2.pkl'))
dk=mg[mg.dk_tier=='high']
print(dk['action'].value_counts()); print()
for a in ['Promised follow-up — now due','Reply now — they asked to meet','They said "later" — window open']:
    print('###',a)
    for r in dk[dk.action==a].sort_values('prio',ascending=False).head(14).itertuples():
        print(f'  {r.prio:5.0f} {r.name[:26]:26} | {str(r.Company)[:24]:24} | {str(r.Position)[:38]:38} | due {r.due_date} ({r.due_label}) | last {r.last_date:%Y-%m-%d}')
    print()
