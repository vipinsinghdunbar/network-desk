import os as _os
_D1 = chr(47)+'tmp'+chr(47)+'li'
_D2 = chr(47)+'tmp'+chr(47)+'work'
SRC  = _os.environ.get('ND_SRC',  _D1)
WORK = _os.environ.get('ND_WORK', _D2)

from urllib.parse import unquote
import pandas as pd, re, json, numpy as np, unicodedata
import importlib.util
c=pd.read_pickle(_os.path.join(WORK, 'final2.pkl')).fillna('')
c['co_l']=c['Company'].str.lower().str.strip()

# reuse DK company logic
import importlib.util as _iu
_sp=_iu.spec_from_file_location("dkmod",_os.path.join(WORK, "dk.py")); _m=_iu.module_from_spec(_sp); _sp.loader.exec_module(_m)
DK_COMPANIES=_m.DK_COMPANIES; DK_SUFFIX=_m.DK_SUFFIX; DK_INFIX=_m.DK_INFIX
dk_name_score=_m.dk_name_score
def co_is_dk(co):
    cl=str(co).lower().strip()
    if not cl: return False
    if cl in DK_COMPANIES: return True
    if any(cl.endswith(s) for s in DK_SUFFIX) or any(s in cl for s in DK_INFIX): return True
    return False

def norm_co(s):
    s=str(s).lower().strip()
    s=re.sub(r'\s*[·|].*$','',s)
    s=re.sub(r'\b(a/s|aps|group|gruppen|as|ab|inc|ltd|plc|denmark|danmark|nordics?)\b','',s)
    return re.sub(r'[^a-z0-9æøå]+','',s)
c['co_n']=c['Company'].apply(norm_co)
bykey={}
for k,g in c[c.co_n!=''].groupby('co_n'):
    bykey[k]=g

sj=pd.read_csv(_os.path.join(SRC, 'Jobs/Saved Jobs.csv')).fillna('')
sj['d']=pd.to_datetime(sj['Saved Date'],format='%m/%d/%y, %I:%M %p',errors='coerce')
ja=pd.read_csv(_os.path.join(SRC, 'Jobs/Job Applications.csv')).fillna('')
ja['d']=pd.to_datetime(ja['Application Date'],format='%m/%d/%y, %I:%M %p',errors='coerce')

targets={}
def add(co,kind,title,date,url=''):
    if not str(co).strip(): return
    k=norm_co(co)
    if not k: return
    t=targets.setdefault(k,dict(co=str(co).strip(),saved=[],applied=[]))
    if len(str(co).strip())>len(t['co']) and kind=='saved': pass
    t[kind].append(dict(t=str(title).strip(),d=(date.strftime('%Y-%m-%d') if pd.notna(date) else ''),u=str(url)))
# Column ORDER differs between the archive export and the API, so address by name only.
for _, r in sj.iterrows(): add(r['Company Name'], 'saved',   r['Job Title'], r['d'], r.get('Job Url',''))
for _, r in ja.iterrows(): add(r['Company Name'], 'applied', r['Job Title'], r['d'], r.get('Job Url',''))

rows=[]
for k,t in targets.items():
    g=bykey.get(k)
    n=len(g) if g is not None else 0
    dkn=int((g.dk_tier=='high').sum()) if n else 0
    best=[]
    if n:
        gg=g.sort_values(['role_score','prio'],ascending=False).head(4)
        for r in gg.itertuples():
            best.append(dict(n=r.name,p=str(r.Position),u=r.URL,rt=r.role_tags,a=r.action,m=int(r.msgs),
                             rc=int(r.rc) if hasattr(r,'rc') else int(r.recv)))
    alld=sorted([x['d'] for x in t['saved']+t['applied'] if x['d']],reverse=True)
    rows.append(dict(co=t['co'],k=k,saved=t['saved'],applied=t['applied'],n=n,dkn=dkn,best=best,
                     last=alld[0] if alld else '', dk=co_is_dk(t['co']),
                     ns=len(t['saved']),na=len(t['applied'])))
rows.sort(key=lambda r:(r['last'] or ''),reverse=True)
print('target companies:',len(rows),'| with connections:',sum(1 for r in rows if r['n']),'| zero:',sum(1 for r in rows if not r['n']))
print('recent (2026) with connections:',sum(1 for r in rows if r['n'] and r['last']>='2026-01-01'))

# followed companies, no connections
cf=pd.read_csv(_os.path.join(SRC, 'Company Follows.csv')).fillna('')
cf['d']=pd.to_datetime(cf['Followed On'],format='%a %b %d %H:%M:%S UTC %Y',errors='coerce')
seen=set(c['co_n'])|set(targets.keys())
fol=[]
for r in cf.itertuples():
    k=norm_co(r.Organization)
    if not k or k in seen: continue
    seen.add(k)
    fol.append(dict(co=str(r.Organization).strip(),d=(r.d.strftime('%Y-%m-%d') if pd.notna(r.d) else ''),dk=co_is_dk(r.Organization)))
print('followed, no connection, no application:',len(fol),'| danish-looking:',sum(1 for f in fol if f['dk']))

# members followed, not connected
# LinkedIn appends your member id to this filename, so it differs per account.
import glob as _glob
_mfp=sorted(_glob.glob(_os.path.join(SRC,'Member_Follows*.csv')))
mf=pd.read_csv(_mfp[0]).fillna('') if _mfp else pd.DataFrame(columns=['Date','Status','FullName'])
names=set(c['name'])
peep=[]
for r in mf[mf.Status=='Active'].itertuples():
    nm=str(r.FullName).strip()
    if nm in names: continue
    base=re.sub(r',.*$','',nm).split()
    sc,why=dk_name_score(base[0] if base else '', base[-1] if len(base)>1 else '')
    peep.append(dict(n=nm,d=str(r.Date)[:10],dk=sc>=2,why=';'.join(why)))
print('followed people not connected:',len(peep),'| danish-named:',sum(1 for p in peep if p['dk']))

# pending invites
inv=pd.read_csv(_os.path.join(SRC, 'Invitations.csv')).fillna('')
def nu(u):
    # Connections.csv percent-encodes non-ASCII vanity URLs (dennis-fib%C3%A6k-hansen)
    # while messages.csv stores them decoded (dennis-fibaek-hansen with real ae).
    # Without unquoting, every Danish name containing ae/oe/aa fails to match and the
    # person is reported as never contacted. Decode BOTH sides before comparing.
    u=unquote(str(u).strip()).lower().rstrip('/')
    return re.sub(r'^https?://(www\.)?linkedin\.com/in/','',u).split('?')[0]
out=inv[inv.Direction=='OUTGOING'].copy(); out['k']=out['inviteeProfileUrl'].apply(nu)
out['d']=pd.to_datetime(out['Sent At'],format='%m/%d/%y, %I:%M %p',errors='coerce')
pend=out[~out['k'].isin(set(c['key']))].copy()
pend['nm']=pend['To'].astype(str)
pd_rows=[]
for r in pend.itertuples():
    base=r.nm.split()
    sc,_=dk_name_score(base[0] if base else '', base[-1] if len(base)>1 else '')
    pd_rows.append(dict(n=r.nm,u=r.inviteeProfileUrl,d=(r.d.strftime('%Y-%m-%d') if pd.notna(r.d) else ''),dk=sc>=2))
pd_rows.sort(key=lambda x:x['d'],reverse=True)
print('pending invites:',len(pd_rows),'danish-named:',sum(1 for p in pd_rows if p['dk']))
# ---- company recommendations, computed from his own reply history ----
def recommendations(c, targets_keys):
    h = c[(c.dk_tier=='high') & (c.co_n!='')].copy()
    g = h.groupby('co_n').agg(
        name=('Company', lambda s: s.value_counts().index[0]),
        n=('name','size'),
        key=('role_score', lambda s: (s>=30).sum()),
        contacted=('msgs', lambda s: (s>0).sum()),
        replied=('recv', lambda s: (s>0).sum()),
        never=('msgs', lambda s: (s==0).sum()),
    ).reset_index().rename(columns={'co_n':'ck'})
    overall = h['recv'].gt(0).sum() / max(1, h['msgs'].gt(0).sum())
    g['rate'] = g['replied'] / g['contacted'].replace(0, np.nan)
    g['targeted'] = g['ck'].isin(targets_keys)

    deeper = g[(g.contacted>=4) & (g.rate>=overall*1.4) & (g.never>=1)].copy()
    # NOTE: these three used to be <frame>.apply(<lambda>, axis=1). That is not safe
    # here. On an EMPTY frame pandas returns an empty DataFrame rather than an empty
    # Series, and assigning that to a single column raises
    #   ValueError: Cannot set a DataFrame with multiple columns to the single column
    # which killed the entire build. A network where no company clears the bar is an
    # ordinary network, not a broken export, so an empty list must be acceptable.
    deeper['why'] = [f"{int(r['replied'])} of {int(r['contacted'])} answered you — {r['rate']*100:.0f}% against your {overall*100:.0f}% average, and {int(r['never'])} there have never had a message" for _, r in deeper.iterrows()]
    deeper = deeper.sort_values(['rate','n'], ascending=False).head(24)

    untapped = g[(~g.targeted) & (g.key>=3) & (g.n>=5)].copy()
    untapped['why'] = [f"{int(r['key'])} product, hiring or recruiting people among {int(r['n'])} contacts, and you have never saved or applied to a role here" for _, r in untapped.iterrows()]
    untapped = untapped.sort_values(['key','n'], ascending=False).head(24)

    quiet = g[(g.n>=8) & (g.contacted/g.n < 0.45)].copy()
    quiet['why'] = [f"{int(r['n'])} contacts but only {int(r['contacted'])} ever messaged — the largest unused footprint you have" for _, r in quiet.iterrows()]
    quiet = quiet.sort_values('n', ascending=False).head(24)

    def pack(df, kind):
        return [dict(co=r['name'], ck=r['ck'], n=int(r['n']), key=int(r['key']),
                     contacted=int(r['contacted']), replied=int(r['replied']), never=int(r['never']),
                     rate=(None if pd.isna(r['rate']) else round(float(r['rate'])*100)),
                     why=r['why'], kind=kind) for _, r in df.iterrows()]
    return dict(deeper=pack(deeper,'deeper'), untapped=pack(untapped,'untapped'),
                quiet=pack(quiet,'quiet'), overall_rate=round(overall*100))

recs = recommendations(c, set(targets.keys()))
print('recommendations:', {k:(len(v) if isinstance(v,list) else v) for k,v in recs.items()})

# ---------------------------------------------------------------------------
# "Grow here" - what to do about a company once you know who you have there.
#
# The desk can name your route in and the gap in your coverage, both from your
# own data. It cannot name people you are NOT connected to: the export contains
# only your own network, and scraping profiles would break LinkedIn's terms and
# mean compiling records on people who never agreed to it. So for the unknown
# half it builds the LinkedIn search instead - which is better anyway, because
# LinkedIn marks who shares a connection with you and a scraped list cannot.
# ---------------------------------------------------------------------------
_ROLES=[('Product Manager','Product Managers'),
        ('Product Owner','Product Owners'),
        ('Head of Product','Heads of Product'),
        ('Engineering Manager','Engineering leads'),
        ('Talent Acquisition','Recruiters')]
def _ppl_url(company, title=None, geo=True):
    import urllib.parse as _u
    q={'keywords':company}
    if title: q['keywords']=f'{company} {title}'
    url='https://www.linkedin.com/search/results/people/?'+_u.urlencode(q)
    if geo: url+='&geoUrn=%5B%22106315554%22%5D'   # Denmark
    return url

grow={}
_hh=c.copy(); _hh['ck']=_hh['Company'].apply(norm_co)
for ck,g in _hh[_hh.ck!=''].groupby('ck'):
    disp=g['Company'].value_counts().index[0]
    tags=' ; '.join(g['role_tags'].fillna(''))
    have=dict(product=int(g['role_tags'].fillna('').str.contains('Product|PO/PM').sum()),
              senior=int(g['role_tags'].fillna('').str.contains('Senior decision').sum()),
              recruit=int(g['role_tags'].fillna('').str.contains('Recruiter').sum()))
    # Who would actually make an introduction: someone who answered you beats
    # someone senior who never did.
    g2=g.copy()
    g2['intro']=(pd.to_numeric(g2['recv'],errors='coerce').fillna(0).clip(upper=5)*3 + pd.to_numeric(g2['ever_warm'],errors='coerce').fillna(0).astype(int)*4
                 + pd.to_numeric(g2['role_score'],errors='coerce').fillna(0)*0.06 - (g2['days_since'].fillna(999)/200).clip(upper=4))
    best=g2.sort_values('intro',ascending=False).head(3)
    routes=[dict(n=r.name,p=str(r.Position),u=r.URL,rc=int(r.recv),
                 d=(int(r.days_since) if r.days_since==r.days_since and r.days_since else None))
            for r in best.itertuples() if r.recv>0 or r.msgs>0][:3]
    gaps=[]
    if not have['product']: gaps.append('nobody in product')
    if not have['senior']:  gaps.append('nobody senior')
    if not have['recruit']: gaps.append('no recruiter')
    grow[ck]=dict(c=disp,n=int(len(g)),routes=routes,gaps=gaps)
print('grow panels:',len(grow))

# companies you follow with nobody inside - the largest untouched pool there is
_known=set(_hh['ck'])
_fol_grow=[]
for r in fol:
    ck=norm_co(r['co'])
    if ck and ck not in _known and ck not in grow:
        _fol_grow.append(ck)
        grow[ck]=dict(c=r['co'],n=0,routes=[],gaps=['no connections at all'],
                      followed=r.get('d',''))
print('  plus',len(_fol_grow),'companies you follow with nobody inside')

json.dump(dict(targets=rows,followed=fol,people=peep,pending=pd_rows,recs=recs,grow=grow),
          open(_os.path.join(WORK, 'expand.json'),'w',encoding='utf-8'),ensure_ascii=False)
import os; print('KB',os.path.getsize(_os.path.join(WORK, 'expand.json'))//1024)
