import os as _os
_D1 = chr(47)+'tmp'+chr(47)+'li'
_D2 = chr(47)+'tmp'+chr(47)+'work'
SRC  = _os.environ.get('ND_SRC',  _D1)
WORK = _os.environ.get('ND_WORK', _D2)

from urllib.parse import unquote
import pandas as pd, re, numpy as np
c = pd.read_pickle(_os.path.join(WORK, 'conn.pkl'))
m = pd.read_csv(_os.path.join(SRC, 'messages.csv')).fillna('')
def nu(u):
    # Connections.csv percent-encodes non-ASCII vanity URLs (dennis-fib%C3%A6k-hansen)
    # while messages.csv stores them decoded. Without unquoting, every Danish name
    # containing ae/oe/aa fails to match and the person reads as never contacted.
    u=unquote(str(u).strip()).lower().rstrip('/')
    u=re.sub(r'^https?://(www\.)?linkedin\.com/in/','',u)
    return u.split('?')[0]
# Who is "me"? Not hardcoded: the export belongs to whoever downloaded it.
# The account holder is the one profile that appears on BOTH sides of the message
# log - every other person appears only as the other party in their own threads.
# config.json overrides it for the rare account where that is ambiguous.
def _find_me(msgs):
    import json as _json
    cfg=_os.path.join(WORK,'config.json')
    if _os.path.exists(cfg):
        try:
            u=_json.load(open(cfg,encoding='utf-8')).get('profile_url','')
            if u: return nu(u)
        except Exception: pass
    snd=msgs['SENDER PROFILE URL'].apply(nu)
    rcv=msgs['RECIPIENT PROFILE URLS'].apply(lambda x: nu(str(x).split(',')[0]))
    both=set(snd)&set(rcv)
    both.discard('')
    if not both:
        raise SystemExit("Could not work out which profile is yours from messages.csv.\n"
                         "Create config.json next to build_desk.py containing:\n"
                         '  {"profile_url": "https://www.linkedin.com/in/your-vanity-name"}')
    counts=snd.value_counts()
    return max(both,key=lambda k:counts.get(k,0))
ME=_find_me(m)
print('identified you as:',ME)
open(_os.path.join(WORK,'_me.txt'),'w',encoding='utf-8').write(ME)
m['s']=m['SENDER PROFILE URL'].apply(nu)
m['r']=m['RECIPIENT PROFILE URLS'].apply(lambda x: nu(str(x).split(',')[0]))
m['DATE']=pd.to_datetime(m['DATE'].str.replace(' UTC',''),errors='coerce')
m['other']=np.where(m['s']==ME, m['r'], m['s'])
m['out']=m['s']==ME
m=m[m['other']!='']
m=m[m['other']!=ME]

g=m.sort_values('DATE').groupby('other')
rows=[]
for k,d in g:
    last=d.iloc[-1]; first=d.iloc[0]
    n_out=int(d['out'].sum()); n_in=int((~d['out']).sum())
    they_names=[x for x in d.loc[~d['out'],'FROM'].unique() if x]
    rows.append(dict(other=k, msgs=len(d), sent=n_out, recv=n_in,
        first_date=first['DATE'], last_date=last['DATE'],
        last_from_me=bool(last['out']), last_text=str(last['CONTENT'])[:600],
        who_started='me' if first['out'] else 'them',
        their_name=they_names[0] if they_names else '',
        first_text=str(first['CONTENT'])[:400],
        folder=last['FOLDER'],
        all_text=' || '.join(f"[{r.DATE:%Y-%m-%d} {'ME' if r.out else 'THEM'}] {str(r.CONTENT)[:400]}" for r in d.itertuples())[:4000]))
th=pd.DataFrame(rows)
th['live_new']=False

# ---------------------------------------------------------------------------
# Fold in the live changelog.
#
# LinkedIn rebuilds the snapshot above on its own schedule, so it is routinely
# hours to days behind. The changelog is current to the minute but names nobody:
# its message events carry a thread id and nothing else identifying.
#
# Those thread ids turn out to be the snapshot's CONVERSATION ID, verbatim
# (measured: 54 of 55 live threads matched). So the thread id is the bridge. It
# cannot say WHO a message went to, but it says which conversation moved, and
# the snapshot already knows who that conversation is with.
#
# Result: last-contact dates and "waiting on you" stay current without waiting
# for the batch. Message TEXT is deliberately not carried across -- there is not
# enough in a changelog event to attribute a body safely.
# ---------------------------------------------------------------------------
import json as _json
_cl_path=_os.path.join(WORK,'_changelog.json')
if _os.path.exists(_cl_path):
    try:
        _cl=_json.load(open(_cl_path,encoding='utf-8'))
        _live=_cl.get('threads') or {}
        # conversation id -> the other person in it, from the snapshot just parsed
        _cid=(m[m['other']!='']
              .groupby('CONVERSATION ID')['other']
              .agg(lambda s: s.value_counts().index[0]).to_dict())
        _idx={r:i for i,r in enumerate(th['other'])}
        _upd=_new=_orphan=0
        _add=[]
        for _tid,_t in _live.items():
            _who=_cid.get(_tid)
            if not _who:
                _orphan+=1          # a conversation the snapshot has never seen
                continue
            _when=pd.Timestamp(int(_t.get('last') or 0),unit='ms') if _t.get('last') else pd.NaT
            _mine=_t.get('last_mine')
            if _mine is None:       # older _changelog.json with no direction: infer
                _mine=True if _t.get('sent',0) and not _t.get('recv',0) else (
                      False if _t.get('recv',0) and not _t.get('sent',0) else None)
            _i=_idx.get(_who)
            if _i is None:
                # movement in a conversation the snapshot holds no messages for
                _add.append(dict(other=_who,msgs=int(_t.get('sent',0))+int(_t.get('recv',0)),
                    sent=int(_t.get('sent',0)),recv=int(_t.get('recv',0)),
                    first_date=_when,last_date=_when,
                    last_from_me=bool(_mine) if _mine is not None else True,
                    last_text='',who_started='me' if _mine else 'them',their_name='',
                    first_text='',folder='INBOX',all_text='',live_new=True))
                _new+=1
                continue
            th.at[_i,'sent']=int(th.at[_i,'sent'])+int(_t.get('sent',0))
            th.at[_i,'recv']=int(th.at[_i,'recv'])+int(_t.get('recv',0))
            th.at[_i,'msgs']=int(th.at[_i,'msgs'])+int(_t.get('sent',0))+int(_t.get('recv',0))
            if pd.notna(_when) and (pd.isna(th.at[_i,'last_date']) or _when>th.at[_i,'last_date']):
                th.at[_i,'last_date']=_when
                if _mine is not None: th.at[_i,'last_from_me']=bool(_mine)
                th.at[_i,'live_new']=True
                _upd+=1
        if _add: th=pd.concat([th,pd.DataFrame(_add)],ignore_index=True)
        print(f'live changelog: {len(_live)} threads -> {_upd} updated, {_new} newly seen, '
              f'{_orphan} not in the snapshot')
    except Exception as _e:
        print('live changelog skipped:',_e)

NOW=pd.Timestamp('2026-09-25')
th['days_since']=(NOW-th['last_date']).dt.days

def status(r):
    if r['recv']==0: return 'No reply yet' if r['days_since']<=21 else 'Never replied'
    if not r['last_from_me']: return 'Waiting on you'
    if r['sent']>0 and r['recv']>0: return 'Two-way conversation'
    return 'Other'
th['status']=th.apply(status,axis=1)
c['key']=c['URL'].apply(nu)
mg=c.merge(th,left_on='key',right_on='other',how='left')
mg['msgs']=mg['msgs'].fillna(0)
# people with no thread merge in as NaN; a later fillna('') would turn this column
# into mixed strings and booleans, and .sum() on it raises. Pin it to bool here.
mg['live_new']=mg['live_new'].fillna(False).astype(bool)
mg['status']=mg['status'].fillna('Never messaged')
print(mg['status'].value_counts())
print('--- DK high tier ---')
print(mg[mg.dk_tier=='high']['status'].value_counts())
print('--- threads not in connections:', (~th['other'].isin(set(c['key']))).sum(), 'of', len(th))
mg.to_pickle(_os.path.join(WORK, 'merged.pkl')); th.to_pickle(_os.path.join(WORK, 'threads.pkl'))
