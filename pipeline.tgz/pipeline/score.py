import os as _os
_D1 = chr(47)+'tmp'+chr(47)+'li'
_D2 = chr(47)+'tmp'+chr(47)+'work'
SRC  = _os.environ.get('ND_SRC',  _D1)
WORK = _os.environ.get('ND_WORK', _D2)

from urllib.parse import unquote
import pandas as pd, numpy as np, re
mg=pd.read_pickle(_os.path.join(WORK, 'merged.pkl')).fillna('')
inv=pd.read_csv(_os.path.join(SRC, 'Invitations.csv')).fillna('')
def nu(u):
    # Connections.csv percent-encodes non-ASCII vanity URLs (dennis-fib%C3%A6k-hansen)
    # while messages.csv stores them decoded (dennis-fibaek-hansen with real ae).
    # Without unquoting, every Danish name containing ae/oe/aa fails to match and the
    # person is reported as never contacted. Decode BOTH sides before comparing.
    u=unquote(str(u).strip()).lower().rstrip('/')
    return re.sub(r'^https?://(www\.)?linkedin\.com/in/','',u).split('?')[0]
conn_keys=set(mg['key'])
out=inv[inv.Direction=='OUTGOING'].copy(); out['k']=out['inviteeProfileUrl'].apply(nu)
inc=inv[inv.Direction=='INCOMING'].copy(); inc['k']=inc['inviterProfileUrl'].apply(nu)
mg['they_invited_me']=mg['key'].isin(set(inc['k']))

def role(p):
    t=str(p).lower()
    hire = bool(re.search(r'\b(head of|vp |vice president|director|chief|cto|cpo|coo|ceo|founder|co-founder|partner|owner of|managing)\b',t))
    lead = bool(re.search(r'\b(lead|leader|manager|chef|direktør|team lead|delivery)\b',t))
    prod = bool(re.search(r'\b(product|produkt|portfolio)\b',t))
    po   = bool(re.search(r'\b(product owner|produktejer|product manager|produktchef|po\b|product lead)\b',t))
    agile= bool(re.search(r'\b(scrum|agile|safe|rte|release train|coach|transformation)\b',t))
    rec  = bool(re.search(r'\b(talent acquisition|recruit|recruiter|rekrutter|headhunt|sourcing specialist|people & culture|hr business partner|staffing)\b',t))
    eng  = bool(re.search(r'\b(engineer|developer|udvikler|architect|arkitekt|qa|tester|data scien)\b',t))
    s=0; tags=[]
    if prod and hire: s+=45; tags.append('Product leader — can hire')
    elif hire: s+=28; tags.append('Senior decision-maker')
    if po: s+=30; tags.append('PO/PM peer')
    elif prod and lead: s+=22; tags.append('Product lead')
    elif prod: s+=15; tags.append('Product function')
    if rec: s+=32; tags.append('Recruiter / TA')
    if agile: s+=12; tags.append('Agile / SAFe')
    if lead and not hire and not prod: s+=8
    if eng and not prod and not hire: s+=2
    return s, '; '.join(tags)
mg['role_score'],mg['role_tags']=zip(*mg['Position'].apply(role))

POS=r"(let'?s (connect|find|catch|talk|meet|grab)|when are you free|happy to|sure thing|sounds good|my email|call me|book a|send me your|feel free to reach|glad to|would love to|yes,? |i'?m free|talk to you|looking forward|let me know when|ping me|coffee)"
NEG=r"(no thanks?|i'?ll pass|not (the right|able|looking|interested)|unfortunately|don'?t have (the )?time|sorry.{0,25}(but|can'?t|not)|no vacan|wishing you the best|good luck)"
CLOSE=r"^(thanks|thank you|tak|you too|same to you|👍|ok|okay|great|perfect|noted|cheers)[\s\.,!:)👍🙏🎉]*$"
def sentiment(txt, last_from_me, recv):
    if recv==0: return ''
    if last_from_me: return ''
    t=str(txt).strip().lower()
    if re.match(CLOSE,t): return 'Polite close'
    if re.search(NEG,t): return 'Declined'
    if re.search(POS,t): return 'Warm — wants to talk'
    if len(t)>120: return 'Substantive reply'
    return 'Neutral'
mg['reply_type']=[sentiment(a,b,c) for a,b,c in zip(mg['last_text'],mg['last_from_me'],mg['recv'])]
def any_warm(alltext):
    parts=[p for p in str(alltext).split(' || ') if ' THEM]' in p]
    return any(re.search(POS,p.lower()) for p in parts)
mg['ever_warm']=mg['all_text'].apply(any_warm)
for c in ['days_since','msgs','sent','recv']:
    mg[c]=pd.to_numeric(mg[c],errors='coerce').fillna(0)
mg[['msgs','sent','recv']]=mg[['msgs','sent','recv']].astype(int)
mg['Connected On']=pd.to_datetime(mg['Connected On'],format='%d %b %Y',errors='coerce')
mg.to_pickle(_os.path.join(WORK, 'final.pkl'))
print('scored', len(mg))
