import os as _os
_D1 = chr(47)+'tmp'+chr(47)+'li'
_D2 = chr(47)+'tmp'+chr(47)+'work'
SRC  = _os.environ.get('ND_SRC',  _D1)
WORK = _os.environ.get('ND_WORK', _D2)

import pandas as pd, re, unicodedata, json
c = pd.read_csv(_os.path.join(SRC, 'Connections.csv'), skiprows=3)
c = c.fillna('')
c['Company']=c['Company'].str.strip()
c['Position']=c['Position'].str.strip()
c['name']=(c['First Name']+' '+c['Last Name']).str.strip()

# ---------- Danish name signals ----------
DK_SUR_END = ('sen','søn','gaard','gård','holm','lund','strøm','bæk','dahl','kjær','kiær',
              'vang','toft','skov','høj','bak','riis','krogh','mose','næs','ø','ager','borg',
              'gren','bech','beck','kjaer','damgaard','have','felt','løv','trup','rup','lev','strup')
DK_SUR_EXACT = set('''jensen nielsen hansen pedersen andersen christensen larsen sørensen rasmussen jørgensen
petersen madsen kristensen olsen thomsen christiansen poulsen johansen møller mortensen knudsen
jakobsen mikkelsen frederiksen laursen holm henriksen lund schmidt eriksen sørensen kristiansen
bech dahl bruun holst kofoed lindberg birch bang toft vestergaard østergaard nørgaard søndergaard
damgaard hjorth koch clausen bertelsen svendsen simonsen villadsen iversen jespersen nissen ravn
lauritsen carstensen brandt kaas munk munch schou skov steffensen sonne dam bonde bisgaard bjerre
kruse falk holmberg kjeldsen agerbo vinther'''.split())
DK_FIRST = set('''lars anders jens mads morten søren rasmus kasper mikkel jesper niels ole peter poul
henrik thomas martin christian frederik kristian bjørn troels jacob jakob esben magnus emil oliver
malthe villads asger gustav mathias tobias sebastian nikolaj mikael steen bent finn erik knud kim
brian jan flemming claus jesper hans ib torben allan preben leif svend arne gert palle mogens jørn
anne mette hanne lene pia susanne charlotte camilla louise line signe maja freja ida sofie sophie
karen kirsten inge birgitte helle bodil dorte tine trine rikke stine astrid nanna clara laura
josefine katrine cecilie caroline amalie mille julie emma ellen marie gitte lotte vibeke annette
jeanette bettina winnie randi elsebeth solveig kristina benedikte mette-marie ditte maria'''.split())
NO_SE_MARKERS = ('sson','qvist','kvist','ström','sjö','berglund','lindqvist')

def norm(s): return s.lower().strip()
def dk_name_score(first,last):
    f,l = norm(first), norm(last)
    sc=0; why=[]
    if any(l.endswith(x) for x in NO_SE_MARKERS): return -2,['swedish-name']
    if l in DK_SUR_EXACT: sc+=2; why.append('danish-surname')
    elif any(l.endswith(x) for x in DK_SUR_END) and len(l)>4: sc+=1; why.append('danish-surname-form')
    if f.split()[0] in DK_FIRST if f else False: sc+=1; why.append('danish-firstname')
    if re.search(r'[æøå]',f+l): sc+=2; why.append('danish-chars')
    if re.search(r'[äö]',f+l): sc-=1
    return sc,why

# ---------- Danish job-title language ----------
DK_TITLE_WORDS = ['produktejer','direktør','chef','udvikler','konsulent','leder','ansvarlig','rådgiver',
 'projektleder','forretning','ingeniør','medarbejder','afdeling','indkøb','salg','kunde','løsning',
 'udvikling','ledelse','virksomhed','arbejde','erhverv','tekniker','uddannelse','studerende','sikkerhed',
 'økonomi','marked','ejer','stifter','partner hos','hos ','og ','for ','med ']
def dk_title_score(t):
    tl=norm(t); s=0; why=[]
    hits=[w for w in DK_TITLE_WORDS if w in tl]
    strong=[w for w in hits if w not in ('og ','for ','med ','hos ','partner hos','salg','kunde','marked','ejer','partner')]
    if strong: s+=2; why.append('danish-title:'+strong[0].strip())
    elif hits: s+=1; why.append('danish-word-in-title')
    if re.search(r'[æøå]',tl): s+=1; why.append('danish-chars-title')
    return s,why

# ---------- Curated Danish / DK-HQ or major-DK-presence companies ----------
DK_COMPANIES = """a.p. moller - maersk|maersk|danske bank|novo nordisk|ørsted|vestas|satair|netcompany|dalux|
implement consulting group|pandora|3shape|dfds|the lego group|lego|wsaudiology|simcorp|coloplast|
bec financial technologies|bec|gn group|demant|dsb|dsv - global transport and logistics|dsv|cowi|trackunit|
carlsberg group|velux|danfoss|nordea|ambu a/s|nykredit|lunar|wsa – wonderful sound for all|grundfos|nnit|
terma group|jabra|eg a/s|eg|falck|milestone systems|ramboll|scales group a/s|mercell|ubsend|alm. brand group|
signifly|bang & olufsen|saxo|saxo bank|jysk|bankdata|norlys|danfoss climate solutions|tdc erhverv|tryg|
pwc danmark|nne|trustpilot|pleo|siemens gamesa|flying tiger copenhagen|too good to go|topsoe|
freetrailer group a/s|kmd|ocean.io|electricity maps|veo technologies|spirii|udviklings- og forenklingsstyrelsen|
signifly - digital innovation agency|tdc brands|invisio|copenhagen airports a/s|flatpay|bestseller|
jn data|autoproff danmark a/s|sos international|zeronorth|atea danmark|radiometer|impact commerce|aeven|
bavarian nordic|hansen toft|orifarm|systematic a/s|e-conomic|ooono|copenhagen capacity|jobindex a/s|
rockwool group|planday|novonesis|moment a/s|randstad danmark|autorola group|whatever a/s|stark group|
group.one|abacus medicine|ascendis pharma|zendesk|boozt|better collective|nets|nexi group|
lundbeck|leo pharma|genmab|alk|chr. hansen|arla foods|salling group|coop danmark|matas|magasin|
maersk drilling|nordic semiconductor|gomore|monta|corti|templafy|siteimprove|unity|zealand pharma|
ferring|william demant|oticon|gn store nord|widex|dagrofa|nykredit|jyske bank|sydbank|spar nord|
arbejdernes landsbank|lb forsikring|topdanmark|pfa|atp|danica pension|velliv|industriens pension|
københavns kommune|region hovedstaden|region midtjylland|banedanmark|metroselskabet|energinet|
hofor|dtu|technical university of denmark|copenhagen business school|cbs|aarhus universitet|
københavns universitet|university of copenhagen|aalborg university|it university of copenhagen|
grundfos|linak|lm wind power|man energy solutions|everllence|haldor topsoe|fls|flsmidth|
gn audio|epos|sonova denmark|napatech|configit|cim|forecast|dixa|peakon|famly|lunar bank|
mobilepay|vivino|just eat|hesehus|charlie tango|frankly|onomondo|capture one|dwarf|conscia|
viegand maagøe|chronoshub|framna|nodes|shape a/s|it minds|itm8|fellowmind|twoday|vertica|
mjølner informatics|delegate|globeteam|netic|nine a/s|immeo|knowit danmark|bluefragments|
strømlin|24-7|comm2ig|progressive|edora|inversion|greenmobility|donkey republic|clever|
gubi|hay|fritz hansen|kvadrat|louis poulsen|royal copenhagen|georg jensen|ecco|jack & jones|
ganni|samsøe samsøe|nnit|deif|kamstrup|brüel & kjær|hbk|teknologisk institut|force technology|
alexandra instituttet|dhi|aquaporin|unisense|stibo systems|stibo|lundbeckfonden|novo holdings|
sund & bælt|femern|arriva danmark|movia|nobina danmark|scandlines|molslinjen|norwegian|
nykredit realkredit|totalkredit|lån & spar bank|merkur|arbejdsmarkedets tillægspension""".replace('\n','').split('|')
DK_COMPANIES = set(x.strip().lower() for x in DK_COMPANIES if x.strip())
DK_SUFFIX = (' a/s',' aps',' i/s',' k/s',' a/s.',' danmark',' denmark',' dk')
DK_INFIX = ('danmark','denmark','copenhagen','københavn','aarhus','odense','aalborg','danish','dansk','nordisk','nordic ')

c['dk_name'], c['dk_name_why'] = zip(*c.apply(lambda r: dk_name_score(r['First Name'],r['Last Name']), axis=1))
c['dk_title'], c['dk_title_why'] = zip(*c['Position'].apply(dk_title_score))

# data-driven company danishness
comp_stats = c[c['Company']!=''].groupby(c['Company'].str.lower()).agg(
    n=('name','size'), dkname=('dk_name', lambda s:(s>=2).mean()), dktitle=('dk_title', lambda s:(s>=2).mean()))
comp_stats['inferred_dk'] = ((comp_stats.n>=3) & ((comp_stats.dkname>=0.5)|(comp_stats.dktitle>=0.4))) | \
                            ((comp_stats.n>=6) & (comp_stats.dkname>=0.35))
inferred = set(comp_stats[comp_stats.inferred_dk].index)

def company_dk(co):
    if not co: return 0,[]
    cl = co.lower().strip()
    if cl in DK_COMPANIES: return 3,['danish-company']
    if any(cl.endswith(s) for s in DK_SUFFIX) or any(s in cl for s in DK_INFIX): return 3,['danish-company-name']
    if cl in inferred: return 2,['company-mostly-danish-staff']
    return 0,[]

c['dk_comp'], c['dk_comp_why'] = zip(*c['Company'].apply(company_dk))
c['dk_score'] = c['dk_comp'] + c['dk_name'].clip(lower=0) + c['dk_title']
c['dk_why'] = (c['dk_comp_why'] + c['dk_name_why'] + c['dk_title_why']).apply(lambda x: ';'.join(x))

def tier(r):
    if r['dk_comp']>=3 and (r['dk_name']>=2 or r['dk_title']>=2): return 'high'
    if r['dk_comp']>=3: return 'high'
    if r['dk_comp']>=2 and (r['dk_name']>=2 or r['dk_title']>=2): return 'high'
    if r['dk_name']>=3 or (r['dk_name']>=2 and r['dk_title']>=1) or r['dk_title']>=3: return 'high'
    if r['dk_score']>=2: return 'medium'
    return 'low'
c['dk_tier']=c.apply(tier,axis=1)
print(c['dk_tier'].value_counts())
c.to_pickle(_os.path.join(WORK, 'conn.pkl'))
print(comp_stats[comp_stats.inferred_dk].sort_values('n',ascending=False).head(30))
